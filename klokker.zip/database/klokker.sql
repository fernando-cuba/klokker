-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 10-05-2023 a las 19:54:47
-- Versión del servidor: 8.0.30
-- Versión de PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `klokker`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `marcas`
--

CREATE TABLE `marcas` (
  `id__marca` int NOT NULL,
  `nombre__marca` varchar(50) DEFAULT NULL,
  `fecha_actualizacion__marca` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `marcas`
--

INSERT INTO `marcas` (`id__marca`, `nombre__marca`, `fecha_actualizacion__marca`) VALUES
(1, 'Bulova', '2023-05-09 14:20:16'),
(2, 'Caravelle', '2023-05-09 14:20:16'),
(3, 'Casio', '2023-05-09 14:20:17'),
(4, 'Christian Paul', '2023-05-09 14:20:17'),
(5, 'Longines', '2023-05-09 14:20:17'),
(6, 'Mido', '2023-05-09 14:20:17'),
(7, 'Millner', '2023-05-09 14:20:17'),
(8, 'Omega', '2023-05-09 14:20:17'),
(9, 'Rado', '2023-05-09 14:20:17'),
(10, 'ROKR', '2023-05-09 14:20:17'),
(11, 'Slow', '2023-05-09 14:20:17'),
(12, 'Tag Heuer', '2023-05-09 14:20:17'),
(13, 'Tissot', '2023-05-09 14:20:17'),
(14, 'Tommy Hilfiger', '2023-05-09 14:20:17');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `relojes`
--

CREATE TABLE `relojes` (
  `id__relojes` int NOT NULL,
  `modelo__relojes` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `descripcion__relojes` text NOT NULL,
  `nivel_uso__relojes` varchar(50) NOT NULL,
  `genero__relojes` varchar(25) DEFAULT NULL,
  `status_sistema__relojes` varchar(15) NOT NULL,
  `id_fk_marca` int DEFAULT NULL,
  `fecha_actualizacion__relojes` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `relojes`
--

INSERT INTO `relojes` (`id__relojes`, `modelo__relojes`, `descripcion__relojes`, `nivel_uso__relojes`, `genero__relojes`, `status_sistema__relojes`, `id_fk_marca`, `fecha_actualizacion__relojes`) VALUES
(1, 'C977745', 'Reloj Bulova', 'Nuevo', 'Dama', 'Inactivo', 1, '2023-05-09 17:21:58'),
(2, '45L174', 'Reloj Caravelle', 'Nuevo', 'Caballero', 'Activo', 2, '2023-05-09 17:21:58'),
(3, 'WSD-F10RG', 'Reloj Casio', 'Seminuevo', 'Dama', 'Activo', 3, '2023-05-09 17:21:58'),
(4, 'C557755', 'Reloj Christian Paul Velvet', 'Seminuevo', 'Dama', 'Activo', 4, '2023-05-09 17:21:58');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `marcas`
--
ALTER TABLE `marcas`
  ADD PRIMARY KEY (`id__marca`);

--
-- Indices de la tabla `relojes`
--
ALTER TABLE `relojes`
  ADD PRIMARY KEY (`id__relojes`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
