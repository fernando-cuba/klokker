<?php
require_once 'models/marcas/marcasModel.php';
require_once 'models/database/db.php';

class marcasController
{

    private $model;

    public function __CONSTRUCT()
    {
        $this->model = new marcasModel();
    }

    public function Listar_Todos()
    {
        $data = $this->model->Listar();
        return $data;
    }
}
