<?php
require_once 'models/relojes/relojesModel.php';
require_once 'models/database/db.php';

class relojesController
{

    private $model;

    public function __CONSTRUCT()
    {
        $this->model = new relojesModel();
    }

    public function Listar_Todos()
    {
        $data = $this->model->Listar();
        return $data;
    }
    
    public function Guardar($data = []){
        return $this->model->Registrar($data);
    }
    
    public function Eliminar($data = []){
        return $this->model->Eliminar($data);
    }
    
    public function Editar($data = []){
        return $this->model->Editar($data);
    }
}
