<?php
define("AMBIENTE", "DEVELOP");

switch (AMBIENTE) {
    case 'PRODUCTION':
        define("CURRENT_SERVER",  "http://localhost");
        define("DATABASE_DATA",  [
            "USER__DB" =>  "root",
            "HOST__DB" =>  "localhost",
            "PASSWORD__DB" =>  "",
            "DB_NAME__DB" =>  "klokker",
            "CHARSET__DB" =>  "utf8"
        ]);
    break;

    case 'DEVELOP':
    default:
        define("CURRENT_SERVER",  "http://localhost");
        define("DATABASE_DATA",  [
            "USER__DB" =>  "root",
            "HOST__DB" =>  "localhost",
            "PASSWORD__DB" =>  "",
            "DB_NAME__DB" =>  "klokker",
            "CHARSET__DB" =>  "utf8"
        ]);
    break;
}

define("CONFIG__DB", DATABASE_DATA);
