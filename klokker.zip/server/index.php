<?php
header('Content-Type: application/json; charset=utf-8');
$json_data_received = file_get_contents('php://input');
if($json_data_received != "" && $json_data_received != null){
    $data_decoded = json_decode($json_data_received, true);
    $module = isset($data_decoded["c"]) && !empty($data_decoded["c"]) ? $data_decoded["c"] : 'default';
    $action = isset($data_decoded["a"]) && !empty($data_decoded["a"]) ? $data_decoded["a"] : '';
} else{
    $module = isset($_REQUEST["c"]) && !empty($_REQUEST["c"]) ? $_REQUEST["c"] : 'default';
    $action = isset($_REQUEST["a"]) && !empty($_REQUEST["a"]) ? $_REQUEST["a"] : '';
}

switch ($_SERVER['REQUEST_METHOD']) {
    case ('GET' || 'POST' || 'PUT' || 'PATCH' || 'DELETE'):
        if ($module != "default") {
            // ? Instanciamos el controlador
            if (file_exists("controllers/" . $module . "/" . $module . "Controller.php")) {
                include_once "controllers/" . $module . "/" . $module . "Controller.php";
                $controller = $module . 'Controller';
                $controller = new $controller;
                switch ($module) {
                    case 'relojes':
                        switch ($action) {
                            case 'CREATE':
                                echo json_encode(["status" => $controller->Guardar($data_decoded), "data" => $data_decoded]);
                                break;
                            case 'UPDATE':
                                echo json_encode(["status" => $controller->Editar($data_decoded), "data" => $data_decoded]);
                                break;
                            case 'DELETE':
                                echo json_encode(["status" => $controller->Eliminar($data_decoded), "data" => $data_decoded]);
                                break;
                            case 'READ':
                            default:
                                $data = $controller->Listar_Todos();
                                if (count($data) > 0) {
                                    echo json_encode(["status" => true, "data" => $controller->Listar_Todos(), "message" => "SUCCESS"]);
                                } else {
                                    echo json_encode(["status" => false, "data" => [], "message" => "NO_DATA"]);
                                }
                                break;
                        }
                        break;
                    case 'marcas':
                        switch ($action) {
                            case 'READ':
                            default:
                                $data = $controller->Listar_Todos();
                                if (count($data) > 0) {
                                    echo json_encode(["status" => true, "data" => $data, "message" => "SUCCESS"]);
                                } else {
                                    echo json_encode(["status" => false, "data" => [], "message" => "NO_DATA"]);
                                }
                                break;
                        }
                        break;
                    default:
                        echo json_encode(["status" => false, "message" => "NOT_CONTROLLER"]);
                        break;
                }
            } else {
                echo json_encode(["status" => false, "message" => "NOT_MODULE_FIND"]);
            }
        } else {
            echo json_encode(["status" => false, "message" => "NOT_MODULE_FIND"]);
        }
        break;
    default:
        echo json_encode(["status" => false, "message" => "NOT_METHOD"]);
        break;
}
