<?php
class relojesModel
{
    private $pdo;

    public function __CONSTRUCT()
    {
        try {
            $this->pdo = Database::StartUp();
        } catch (Exception $e) {
            die($e->getMessage());
        }
    }

    public function Listar()
    {
        try {
            $result = array();
            $stm = $this->pdo->prepare("SELECT r.id__relojes AS ID, r.modelo__relojes AS modelo, r.descripcion__relojes AS descripcion, r.nivel_uso__relojes AS nivel_uso, r.genero__relojes AS genero, r.status_sistema__relojes as status, r.fecha_actualizacion__relojes as fecha_actualizacion, m.nombre__marca as marca FROM relojes r LEFT JOIN marcas m ON r.id_fk_marca = m.id__marca;");
            $stm->execute();
            $data_relojes = $stm->fetchAll(PDO::FETCH_ASSOC);
            return $data_relojes;
        } catch (Exception $e) {
            die($e->getMessage());
        }
    }

    public function Registrar($data = [])
    {
        try {
            $modelo__relojes = array_key_exists("modelo__watches--input", $data) ? $data["modelo__watches--input"] : "";
            $descripcion__relojes = array_key_exists("descripcion__watches--input", $data) ? $data["descripcion__watches--input"] : "";
            $nivel_uso__relojes = array_key_exists("uso-reloj--input", $data) ? $data["uso-reloj--input"] : "";
            $genero__relojes = array_key_exists("genero-reloj--input", $data) ? $data["genero-reloj--input"] : "";
            $status_sistema__relojes = array_key_exists("status_sistema__watches--input", $data) ? $data["status_sistema__watches--input"] : "";
            $id_fk_marca = array_key_exists("marca-reloj--input", $data) ? $data["marca-reloj--input"] : "";

            $sql = "INSERT INTO relojes 
            (modelo__relojes,
            descripcion__relojes,
            nivel_uso__relojes,
            genero__relojes,
            status_sistema__relojes,
            id_fk_marca) 
            VALUES 
            (?, ?, ?, ?, ?, (SELECT id__marca FROM marcas where nombre__marca = ? LIMIT 1))";
            $status = $this->pdo->prepare($sql)
                ->execute(
                    array(
                        $modelo__relojes,
                        $descripcion__relojes,
                        $nivel_uso__relojes,
                        $genero__relojes,
                        $status_sistema__relojes,
                        $id_fk_marca
                    )
                );
            return $status;
        } catch (Exception $e) {
            die($e->getMessage());
        }
    }

    public function Eliminar($data = [])
    {
        try {
            $id_reloj = array_key_exists("id_reloj", $data) ? $data["id_reloj"] : "";
            $sql = "DELETE FROM relojes WHERE id__relojes = ?";
            $status = $this->pdo->prepare($sql)
                ->execute(
                    array(
                        $id_reloj,
                    )
                );
            return $status;
        } catch (Exception $e) {
            die($e->getMessage());
        }
    }

    
    public function Editar($data = [])
    {
        try {
            $id__relojes = array_key_exists("id_reloj", $data) ? $data["id_reloj"] : "";
            $status_sistema__relojes = array_key_exists("status_sistema__watches--actualizar-input", $data) ? $data["status_sistema__watches--actualizar-input"] : "";
            $modelo__relojes = array_key_exists("modelo__watches--actualizar-input", $data) ? $data["modelo__watches--actualizar-input"] : "";
            $descripcion__relojes = array_key_exists("descripcion__watches--actualizar-input", $data) ? $data["descripcion__watches--actualizar-input"] : "";
            $nivel_uso__relojes = array_key_exists("uso-reloj--actualizar-input", $data) ? $data["uso-reloj--actualizar-input"] : "";
            $genero__relojes = array_key_exists("genero-reloj--actualizar-input", $data) ? $data["genero-reloj--actualizar-input"] : "";
            $id_fk_marca = array_key_exists("marca-reloj--actualizar-input", $data) ? $data["marca-reloj--actualizar-input"] : "";
            $sql = "UPDATE 
                        relojes 
                    SET 
                        modelo__relojes = ?,
                        descripcion__relojes = ?,
                        nivel_uso__relojes = ?,
                        genero__relojes = ?,
                        status_sistema__relojes = ?,
                        id_fk_marca = (SELECT id__marca FROM marcas where nombre__marca = ? LIMIT 1)
                    WHERE 
                        id__relojes = ?";
            $status = $this->pdo->prepare($sql)
                ->execute(
                    array(
                        $modelo__relojes,
                        $descripcion__relojes,
                        $nivel_uso__relojes,
                        $genero__relojes,
                        $status_sistema__relojes,
                        $id_fk_marca, 
                        $id__relojes
                    )
                );
            return $status;
        } catch (Exception $e) {
            die($e->getMessage());
        }
    }
}
