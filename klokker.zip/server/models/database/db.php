<?php
include_once 'config/config.php';

class Database
{
    public static function StartUp()
    {
        $pdo = new PDO('mysql:host='.CONFIG__DB["HOST__DB"].';dbname='.CONFIG__DB["DB_NAME__DB"].';charset='.CONFIG__DB["CHARSET__DB"], CONFIG__DB["USER__DB"], CONFIG__DB["PASSWORD__DB"]);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    }
}