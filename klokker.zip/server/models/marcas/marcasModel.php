<?php
class marcasModel
{
    private $pdo;

    public function __CONSTRUCT()
    {
        try {
            $this->pdo = Database::StartUp();
        } catch (Exception $e) {
            die($e->getMessage());
        }
    }

    public function Listar()
    {
        try {
            $result = array();
            $stm = $this->pdo->prepare("SELECT id__marca as ID, nombre__marca as nombre FROM marcas ORDER BY id__marca ASC");
            $stm->execute();
            $data_marcass = $stm->fetchAll(PDO::FETCH_ASSOC);
            return $data_marcass;
        } catch (Exception $e) {
            die($e->getMessage());
        }
    }
}
