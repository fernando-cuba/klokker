// ? Verificar si existe el elemento
function elementExist(selector = "") {
    return document.body.contains(document.querySelector(selector))
}

// ? Crear datatable
function createDatatable(selector = "") {
    return new DataTable(selector, {
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.10.16/i18n/Spanish.json"
        }
    });
}

// ? Cargar relojes
function loadWatches(selector_container_general = "", selector_table_container = "") {
    // ? Ocultar tabla de relojes
    document.querySelector(selector_container_general).querySelector(selector_table_container).classList.add("d-none")
    // ? Mostrar overlay
    document.querySelector(selector_container_general).querySelector(".partial-overlay").classList.remove("d-none")
    let url_api = `server/?c=relojes&a=READ`
    fetch(url_api)
        .then((response) => {
            return response.json();
        })
        .then((data = {}) => {
            if (data.status) {
                let structure = ""
                for (const iterator of data.data) {
                    structure += `<tr>
                        <td class="text-center">
                            <a href="#" class="btn btn-primary btn-edit-watches" data-id = "${iterator.ID}" 
                            data-modelo="${iterator.modelo}" 
                            data-descripcion="${iterator.descripcion}" 
                            data-marca="${iterator.marca}" 
                            data-genero="${iterator.genero}" 
                            data-nivel_uso="${iterator.nivel_uso}" 
                            data-status="${iterator.status}" 
                            data-bs-toggle="tooltip" data-bs-placement="top" title="Editar reloj">
                                <i class="material-icons m-0">edit</i>
                            </a>
                            <a href="#" class="btn btn-danger btn-delete-watches" data-id_modelo = "${iterator.ID}" data-modelo="${iterator.modelo}" data-bs-toggle="tooltip" data-bs-placement="top" title="Eliminar reloj">
                                <i class="material-icons m-0">delete</i>
                            </a>
                        </td>
                        <td>${iterator.modelo}</td>
                        <td>${iterator.descripcion}</td>
                        <td>${iterator.marca}</td>
                        <td>${iterator.genero}</td>
                        <td>${iterator.nivel_uso}</td>
                        <td>${iterator.status}</td>
                        </tr>`;
                }

                // ? Mostrar tabla de relojes
                document.querySelector(selector_container_general).querySelector(selector_table_container).classList.remove("d-none")
                // ? Ocultar overlay
                document.querySelector(selector_container_general).querySelector(".partial-overlay").classList.add("d-none")
                // ? Destruir tabla
                if ($.fn.DataTable.isDataTable(`${selector_table_container} table`)) {
                    $(`${selector_table_container} table`).DataTable().destroy();
                }
                // ? Limpiar body de tabla
                document.querySelector(selector_table_container).querySelector("table tbody").innerHTML = "";
                document.querySelector(selector_table_container).querySelector("table tbody").innerHTML = structure;
                createDatatable(`${selector_table_container} table`)

                // ? Event para escuchar clic en botón eliminar
                if (elementExist(".btn-delete-watches")) {
                    eventButtonDelete(".btn-delete-watches")
                }

                // ? Event para escuchar clic en botón actualizar
                if (elementExist(".btn-edit-watches")) {
                    eventButtonActualizar(".btn-edit-watches", "#modal-actualizar-reloj", "#modelo-reloj")
                    saveEditedWatches("#form-actualizar-reloj")
                }
                return true;
            }
        })
        .catch(function (error = "") {
            console.log(error);
            return false;
        });
}

// ? Creación de select2
function getSelect(selector = "", selectorModal = "", controller = "") {
    let url_api = `server/?c=${controller}&a=READ`
    fetch(url_api)
        .then((response) => {
            return response.json();
        })
        .then((data = {}) => {
            if (data.status) {
                let structure = ""
                for (const iterator of data.data) {
                    structure += `<option value="${iterator.nombre}">${iterator.nombre}</option>`
                }
                document.querySelector(selector).insertAdjacentHTML("beforeend", structure);
                $(selector).select2({
                    theme: 'bootstrap4',
                    dropdownParent: $(`${selectorModal} .modal-content`)
                });
                return true;
            }
        })
        .catch(function (error = "") {
            console.log(error);
            return false;
        });
}

// ? Guardar Formulario Relojes
function saveWatches(formSelector) {
    document.querySelector(formSelector).addEventListener("submit", (e) => {
        e.preventDefault();
        let formData = new FormData(document.querySelector(formSelector));
        let url_api = "server/";
        formData.append("c", "relojes")
        formData.append("a", "CREATE")
        let obj = {};
        for (let key of formData.keys()) {
            obj[key] = formData.get(key);
        }
        let json_data = JSON.stringify(obj);
        fetch(url_api, {
                method: "POST",
                body: json_data
            })
            .then((response) => {
                return response.json();
            })
            .then((data = {}) => {
                console.log(data);
                if (data.status) {
                    Swal.fire(
                        'Reloj registrado',
                        'El reloj ha sido registrado, gracias por su tiempo',
                        'success'
                    )
                    document.querySelector("#modal-reloj .btn-close").click()
                    document.querySelector("#sync-button").click()
                    document.querySelector("#modal-reloj form").reset()
                }
            })
            .catch(function (error = "") {
                console.log(error);
                return false;
            });
    })
}

// ? Eliminar registro
function deleteWatch(idReloj = "") {
    let obj = {
        "id_reloj": idReloj,
        "c": "relojes",
        "a": "DELETE"
    };
    let json_data = JSON.stringify(obj);
    let url_api = "server/"
    fetch(url_api, {
            method: "POST",
            body: json_data
        })
        .then((response) => {
            return response.json();
        })
        .then((data = {}) => {
            if (data.status) {
                Swal.fire(
                    'Reloj eliminado',
                    'El reloj ha sido eliminado con éxito, gracias por su tiempo',
                    'success'
                )
                document.querySelector("#sync-button").click()
                return true
            } else {
                return false
            }
        })
        .catch(function (error = "") {
            console.log(error);
            return false;
        });
}

// ? Creando evento que escucha el click en botón de eliminar
function eventButtonDelete(selector = "") {
    document.querySelectorAll(selector).forEach(element => {
        element.addEventListener("click", (e) => {
            e.preventDefault();
            let modeloReloj = element.getAttribute("data-modelo")
            Swal.fire({
                title: `¿Desea eliminar el reloj modelo "${modeloReloj}"?`,
                showCancelButton: true,
                confirmButtonText: 'Eliminar',
                confirmButtonColor: '#DD2C59',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    let idReloj = element.getAttribute("data-id_modelo")
                    deleteWatch(idReloj)
                }
            })
        })
    });
}

// ? Creando evento para cargar modal que permite actualizar datos
function eventButtonActualizar(selectorBtn = "", selectorModal = "", selectorModeloReloj = "") {
    document.querySelectorAll(selectorBtn).forEach(element => {
        element.addEventListener("click", () => {
            document.querySelector(`${selectorModal} ${selectorModeloReloj}`).textContent = element.getAttribute("data-modelo")
            document.querySelector("#btn-modal-actualizar").click()
            document.querySelectorAll("[name=status_sistema__watches--actualizar-input]").forEach(elementStatus => {
                if (elementStatus.getAttribute("value") == element.getAttribute("data-status")) {
                    elementStatus.click()
                }
            });
            document.querySelector("[name=modelo__watches--actualizar-input]").value = element.getAttribute("data-modelo")
            document.querySelector("[name=descripcion__watches--actualizar-input]").value = element.getAttribute("data-descripcion")

            document.querySelectorAll("[name=uso-reloj--actualizar-input]").forEach(elementMarca => {
                if (elementMarca.getAttribute("value") == element.getAttribute("data-nivel_uso")) {
                    elementMarca.click()
                }
            });

            document.querySelectorAll("[name=genero-reloj--actualizar-input]").forEach(elementGenero => {
                if (elementGenero.getAttribute("value") == element.getAttribute("data-genero")) {
                    elementGenero.click()
                }
            });

            document.querySelector("#id_reloj").value = element.getAttribute("data-id")

            $('#marca-reloj--actualizar-input').val(element.getAttribute("data-marca")); // Select the option with a value of '1'
            $('#marca-reloj--actualizar-input').trigger('change'); // Notify any JS components that the value changed
        })
    });
}

// ? Guardar Formulario Relojes Editados
function saveEditedWatches(formSelector = "") {
    document.querySelector(formSelector).addEventListener("submit", (e) => {
        e.preventDefault();
        let formData = new FormData(document.querySelector(formSelector));
        let url_api = "server/";
        formData.append("c", "relojes")
        formData.append("a", "UPDATE")

        let obj = {};
        for (let key of formData.keys()) {
            obj[key] = formData.get(key);
        }
        let json_data = JSON.stringify(obj);
        fetch(url_api, {
                method: "PATCH",
                body: json_data
            })
            .then((response) => {
                return response.json();
            })
            .then((data = {}) => {
                console.log(data);
                if (data.status) {
                    Swal.fire(
                        'Reloj actualizado',
                        'El reloj ha sido actualizado, gracias por su tiempo',
                        'success'
                    )
                    document.querySelector("#modal-actualizar-reloj .btn-close").click()
                    document.querySelector("#sync-button").click()
                    document.querySelector("#modal-actualizar-reloj form").reset()
                }
            })
            .catch(function (error = "") {
                console.log(error);
                return false;
            });
    })
}


window.onload = () => {
    // ? Agregar año actual
    document.querySelectorAll(".current_year").forEach(element => {
        element.textContent = new Date().getFullYear()
    })

    // ? Crear tabla de relojes después de cargar la información
    if (elementExist(".table-watches")) {
        loadWatches(".container-general-watches-table", ".container-watches-table")
    }

    // ? Recargar tabla
    if (elementExist("#sync-button")) {
        document.querySelector("#sync-button").addEventListener("click", () => {
            loadWatches(".container-general-watches-table", ".container-watches-table")
        })
    }

    // ? Select para Nivel de uso
    if (elementExist("#marca-reloj--input")) {
        getSelect("#marca-reloj--input", "#modal-reloj", "marcas")
    }

    // ? Event para guardar form 
    if (elementExist("#form-reloj")) {
        saveWatches("#form-reloj")
    }

    // ? Select para Nivel de uso en Actualización
    if (elementExist("#marca-reloj--actualizar-input")) {
        getSelect("#marca-reloj--actualizar-input", "#modal-actualizar-reloj", "marcas")
    }
}