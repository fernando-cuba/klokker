# Hola, soy **Fernando Cuba** 
#### Para comenzar a utilizar la aplicación es necesario importar los archivos de la base de datos los cuales se encuentran en la carpeta [`database/prueba_tecnica.sql`](database/klokker.sql) 
#### A continuación se encuentra que se puede encontrar con la estructura de carpetas y un listo de funcionalidades que tiene esta aplicación:

## Carpetas:
- server
  - config: Tiene un archivo de configuración dónde se debe editar el nombre de la base de datos u otros datos relacionados a la conexión
  - controllers: Contiene los **Controladores**
  - models: Contiene los **Modelos**
  - 
- public
  - assets: Contiene elementos de Tipografía, CSS, JS y librerías ocupadas para alertas y elementos de selección de formularios

## Funcionalidades:
- CRUD asíncrono mediante JS y PHP
- Adición de elementos a Bd en tiempo real
- Visualización de datos en tablas
- Elementos visuales de ayuda como son:
  - Confirmaciones
  - Alertas
  - Iconos
- Funcionamiento en local sin necesidad de conectarse a internet
- Estructura MVC
- Funcionamiento en API (Se puede probar conectándose desde POSTMAN)